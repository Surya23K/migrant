from django.apps import AppConfig


class MigrateappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'migrateapp'
