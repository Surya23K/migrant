# from django.shortcuts import render, redirect
# from .forms import WorkerRegistrationForm  # Make sure this import exists
# from django.contrib.auth import login   
# from .forms import WorkerRegistrationForm  # You missed this import

# def index(request):
#     return render(request, 'index.html')

# def login(request):
#     return render(request, 'login.html')

# from django.shortcuts import render, redirect
# from django.contrib.auth.hashers import make_password
# from django.contrib import messages
# from .models import Registration
# import re

# def registration(request):
#     if request.method == 'POST':
#         # Extract form data
#         name = request.POST.get('name')
#         address = request.POST.get('address')
#         state = request.POST.get('state')
#         district = request.POST.get('district')
#         city = request.POST.get('city')
#         dob = request.POST.get('dob')
#         pincode = request.POST.get('pincode')
#         aadhar = request.POST.get('aadhar')
#         phone = request.POST.get('phone')
#         category = request.POST.get('category')
#         email = request.POST.get('email')
#         password = request.POST.get('password')

#         # Server-side validation
#         errors = []

#         # Validate Aadhar (12 digits)
#         if not re.match(r'^\d{12}$', aadhar):
#             errors.append('Please enter a valid 12-digit Aadhar number.')

#         # Validate phone (10 digits)
#         if not re.match(r'^\d{10}$', phone):
#             errors.append('Please enter a valid 10-digit phone number.')

#         # Validate pincode (6 digits)
#         if not re.match(r'^\d{6}$', pincode):
#             errors.append('Please enter a valid 6-digit pincode.')

#         # Validate password (minimum 8 characters)
#         if len(password) < 8:
#             errors.append('Password must be at least 8 characters long.')

#         # Validate required fields
#         required_fields = {
#             'name': name,
#             'address': address,
#             'state': state,
#             'district': district,
#             'city': city,
#             'dob': dob,
#             'pincode': pincode,
#             'aadhar': aadhar,
#             'phone': phone,
#             'category': category,
#             'email': email,
#             'password': password,
#         }
#         for field_name, field_value in required_fields.items():
#             if not field_value:
#                 errors.append(f'{field_name.capitalize()} is required.')

#         # Check for unique email and Aadhar
#         if Registration.objects.filter(email=email).exists():
#             errors.append('Email is already registered.')
#         if Registration.objects.filter(aadhar=aadhar).exists():
#             errors.append('Aadhar number is already registered.')

#         if errors:
#             # Return errors to the template
#             for error in errors:
#                 messages.error(request, error)
#             return render(request, 'registration.html', {
#                 'form_data': required_fields,
#             })

#         # Save to database
#         try:
#             Registration.objects.create(
#                 name=name,
#                 address=address,
#                 state=state,
#                 district=district,
#                 city=city,
#                 dob=dob,
#                 pincode=pincode,
#                 aadhar=aadhar,
#                 phone=phone,
#                 category=category,
#                 email=email,
#                 password=make_password(password),  # Hash the password
#             )
#             messages.success(request, 'Registration successful! You will receive a confirmation email shortly.')
#             return redirect('register')  # Redirect to the same page or a success page
#         except Exception as e:
#             messages.error(request, f'Registration failed: {str(e)}')
#             return render(request, 'registration.html', {
#                 'form_data': required_fields,
#             })

#     # Render the form for GET request
#     return render(request, 'registration.html')

from django.shortcuts import render, redirect
from django.contrib.auth.hashers import make_password
from django.contrib import messages
from .forms import WorkerRegistrationForm
from .models import Registration

def index(request):
    return render(request, 'index.html')

def login(request):
    return render(request, 'login.html')

def registration(request):
    if request.method == 'POST':
        form = WorkerRegistrationForm(request.POST)
        if form.is_valid():
            try:
                form.save()  # Save the form data to the database
                messages.success(request, 'Registration successful! You will receive a confirmation email shortly.')
                return redirect('register')
            except Exception as e:
                messages.error(request, f'Registration failed: {str(e)}')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f'{field}: {error}')
        return render(request, 'registration.html', {'form': form})
    else:
        form = WorkerRegistrationForm()
    return render(request, 'registration.html', {'form': form})