from django.db import models

# Create your models here.


class Registration(models.Model):
    CATEGORY_CHOICES = [
        ('general', 'General'),
        ('obc', 'OBC (Other Backward Class)'),
        ('sc', 'SC (Scheduled Caste)'),
        ('st', 'ST (Scheduled Tribe)'),
        ('ews', 'EWS (Economically Weaker Section)')
    ]

    STATE_CHOICES = [
        ('kerala', 'Kerala'),
        ('tamil-nadu', 'Tamil Nadu'),
        ('karnataka', 'Karnataka'),
        ('andhra-pradesh', 'Andhra Pradesh'),
        ('telangana', 'Telangana'),
        ('maharashtra', 'Maharashtra'),
        ('gujarat', 'Gujarat'),
        ('rajasthan', 'Rajasthan'),
        ('uttar-pradesh', 'Uttar Pradesh'),
        ('west-bengal', 'West Bengal'),
        ('bihar', 'Bihar'),
        ('odisha', 'Odisha'),
        ('madhya-pradesh', 'Madhya Pradesh'),
        ('punjab', 'Punjab'),
        ('haryana', 'Haryana'),
        ('delhi', 'Delhi')
    ]

    DISTRICT_CHOICES = [
        ('thiruvananthapuram', 'Thiruvananthapuram'),
        ('kollam', 'Kollam'),
        ('pathanamthitta', 'Pathanamthitta'),
        ('alappuzha', 'Alappuzha'),
        ('kottayam', 'Kottayam'),
        ('idukki', 'Idukki'),
        ('ernakulam', 'Ernakulam'),
        ('thrissur', 'Thrissur'),
        ('palakkad', 'Palakkad'),
        ('malappuram', 'Malappuram'),
        ('kozhikode', 'Kozhikode'),
        ('wayanad', 'Wayanad'),
        ('kannur', 'Kannur'),
        ('kasaragod', 'Kasaragod')
    ]

    name = models.CharField(max_length=100)
    address = models.TextField()
    state = models.CharField(max_length=50, choices=STATE_CHOICES)
    district = models.CharField(max_length=50, choices=DISTRICT_CHOICES)
    city = models.CharField(max_length=50)
    dob = models.DateField()
    pincode = models.CharField(max_length=6)
    aadhar = models.CharField(max_length=12, unique=True)
    phone = models.CharField(max_length=10)
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES)
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=128)  # Hashed password
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "Registration"
        verbose_name_plural = "Registrations"