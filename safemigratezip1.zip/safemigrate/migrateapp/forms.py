# from django import forms
# from django.contrib.auth.forms import UserCreationForm
# from django.contrib.auth.models import User

# class WorkerRegistrationForm(UserCreationForm):

#     email = forms.EmailField(required=True)

#     class Meta:
#         model = User
#         fields = ['username', 'email', 'password1', 'password2']


from django import forms
from .models import Registration

class WorkerRegistrationForm(forms.ModelForm):
    class Meta:
        model = Registration
        fields = [
            'name', 'address', 'state', 'district', 'city', 'dob',
            'pincode', 'aadhar', 'phone', 'category', 'email', 'password'
        ]
        widgets = {
            'dob': forms.DateInput(attrs={'type': 'date'}),
            'password': forms.PasswordInput(),
        }

    def clean_aadhar(self):
        aadhar = self.cleaned_data['aadhar']
        if not re.match(r'^\d{12}$', aadhar):
            raise forms.ValidationError('Please enter a valid 12-digit Aadhar number.')
        if Registration.objects.filter(aadhar=aadhar).exists():
            raise forms.ValidationError('Aadhar number is already registered.')
        return aadhar

    def clean_phone(self):
        phone = self.cleaned_data['phone']
        if not re.match(r'^\d{10}$', phone):
            raise forms.ValidationError('Please enter a valid 10-digit phone number.')
        return phone

    def clean_pincode(self):
        pincode = self.cleaned_data['pincode']
        if not re.match(r'^\d{6}$', pincode):
            raise forms.ValidationError('Please enter a valid 6-digit pincode.')
        return pincode

    def clean_password(self):
        password = self.cleaned_data['password']
        if len(password) < 8:
            raise forms.ValidationError('Password must be at least 8 characters long.')
        return password

    def clean_email(self):
        email = self.cleaned_data['email']
        if Registration.objects.filter(email=email).exists():
            raise forms.ValidationError('Email is already registered.')
        return email

    def save(self, commit=True):
        instance = super().save(commit=False)
        instance.password = make_password(self.cleaned_data['password'])
        if commit:
            instance.save()
        return instance
